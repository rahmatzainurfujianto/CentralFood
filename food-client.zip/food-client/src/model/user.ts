export class User {
    constructor(
        public userid: string = "",
        public useremail: string = "",
        public feedback: string = "",
        public name: string = "") {}
}