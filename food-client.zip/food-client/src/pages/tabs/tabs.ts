import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { HomePage } from '../home/home';
import { OrdersPage } from '../orders/orders';
import { SettingsPage } from '../settings/settings';
import { CalendarPage } from '../calendar/calendar';
import { AboutPage } from '../about/about';
@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = HomePage;
  tab2Root = OrdersPage;
  tab3Root = SettingsPage;
  tab4Root = AboutPage;
  tab5Root = CalendarPage;

  constructor(params: NavParams) {

  }
}
