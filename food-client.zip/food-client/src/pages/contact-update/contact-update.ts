import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { UserProvider } from '../../providers/user/user';
/**
 * Generated class for the ContactUpdatePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-contact-update',
  templateUrl: 'contact-update.html',
})
export class ContactUpdatePage {
  private userid: string = "";
  private useremail: string = "";
  private feedback: string ="";
  private name: string = "";
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private userProvider: UserProvider
  ) {
    var data = navParams.data;
    this.userid = data.userid;
    this.useremail = data.useremail;
    this.feedback = data.feedback;
    this.name = data.name;
  }
  updateUser() {
    var data = {
      "feedback": this.feedback,
      "name": this.name
    }
    this.userProvider.updateUser(this.userid, data).subscribe((result) => {
      console.log(result);
      this.navCtrl.pop();
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ContactUpdatePage');
  }

}
