var mysql = require('mysql');
var dbconnect = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "food070"
});

module.exports = dbconnect